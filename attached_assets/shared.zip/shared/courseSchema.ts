import { pgTable, text, varchar, timestamp, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Course purchases table
export const coursePurchases = pgTable("course_purchases", {
  id: integer("id").primaryKey().generatedByDefaultAsIdentity(),
  userId: varchar("user_id").notNull(),
  productId: varchar("product_id").notNull(), // 'starter-kit' or 'branded-by-selfie'
  stripePaymentIntentId: varchar("stripe_payment_intent_id"),
  purchaseDate: timestamp("purchase_date").defaultNow(),
  amount: integer("amount").notNull(), // In cents
  status: varchar("status").default("active"), // active, refunded, expired
  createdAt: timestamp("created_at").defaultNow(),
});

// Course progress tracking
export const courseProgress = pgTable("course_progress", {
  id: integer("id").primaryKey().generatedByDefaultAsIdentity(),
  userId: varchar("user_id").notNull(),
  productId: varchar("product_id").notNull(),
  moduleId: varchar("module_id").notNull(),
  lessonId: varchar("lesson_id"),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completed_at"),
  lastAccessed: timestamp("last_accessed").defaultNow(),
});

// Course content metadata
export const courseContent = pgTable("course_content", {
  id: integer("id").primaryKey().generatedByDefaultAsIdentity(),
  productId: varchar("product_id").notNull(),
  moduleId: varchar("module_id").notNull(),
  lessonId: varchar("lesson_id"),
  title: varchar("title").notNull(),
  description: text("description"),
  videoUrl: varchar("video_url"),
  pdfUrl: varchar("pdf_url"),
  resourceUrls: jsonb("resource_urls"), // Array of additional resources
  orderIndex: integer("order_index").default(0),
  isPublished: boolean("is_published").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const coursePurchasesRelations = relations(coursePurchases, ({ many }) => ({
  progress: many(courseProgress),
}));

export const courseProgressRelations = relations(courseProgress, ({ one }) => ({
  purchase: one(coursePurchases, {
    fields: [courseProgress.userId, courseProgress.productId],
    references: [coursePurchases.userId, coursePurchases.productId],
  }),
  content: one(courseContent, {
    fields: [courseProgress.productId, courseProgress.moduleId, courseProgress.lessonId],
    references: [courseContent.productId, courseContent.moduleId, courseContent.lessonId],
  }),
}));

export const courseContentRelations = relations(courseContent, ({ many }) => ({
  progress: many(courseProgress),
}));

// Types
export type CoursePurchase = typeof coursePurchases.$inferSelect;
export type InsertCoursePurchase = typeof coursePurchases.$inferInsert;
export type CourseProgress = typeof courseProgress.$inferSelect;
export type InsertCourseProgress = typeof courseProgress.$inferInsert;
export type CourseContent = typeof courseContent.$inferSelect;
export type InsertCourseContent = typeof courseContent.$inferInsert;