import fs from 'fs';

// Load the Trello JSON export
const trelloData = JSON.parse(fs.readFileSync('attached_assets/yx5S9hxs - reels-and-story-templates (1).json', 'utf8'));

console.log('🔍 EXTRACTING 30-DAY CONTENT TEMPLATES FROM TRELLO...');

// Extract all cards from the Trello board
const cards = trelloData.cards || [];
console.log(`Found ${cards.length} cards in Trello export`);

// Find template cards and organize them
const templates = {};
let dayCount = 0;

cards.forEach(card => {
  const name = card.name || '';
  const desc = card.desc || '';
  
  // Look for day templates
  if (name.toLowerCase().includes('day') && (name.toLowerCase().includes('template') || desc.length > 50)) {
    console.log(`\n📋 FOUND: ${name}`);
    console.log(`Description preview: ${desc.substring(0, 100)}...`);
    
    // Extract day number
    const dayMatch = name.match(/day\s*(\w+)/i);
    let dayNum = null;
    
    if (dayMatch) {
      const dayStr = dayMatch[1].toLowerCase();
      // Convert word numbers to digits
      const wordToNum = {
        'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
        'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
        'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15,
        'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19, 'twenty': 20,
        'twentyone': 21, 'twentytwo': 22, 'twentythree': 23, 'twentyfour': 24, 'twentyfive': 25,
        'twentysix': 26, 'twentyseven': 27, 'twentyeight': 28, 'twentynine': 29, 'thirty': 30
      };
      
      dayNum = wordToNum[dayStr] || parseInt(dayStr) || null;
    }
    
    if (dayNum && dayNum >= 1 && dayNum <= 30) {
      dayCount++;
      
      // Parse content from description
      const content = parseContentFromDescription(desc, name);
      
      templates[dayNum] = {
        day: dayNum,
        title: name,
        ...content
      };
      
      console.log(`✅ Extracted Day ${dayNum}: ${content.reel_prompt ? 'Has Reel' : 'No Reel'}, ${content.caption_template ? 'Has Caption' : 'No Caption'}`);
    }
  }
});

console.log(`\n🎯 EXTRACTION COMPLETE: Found ${dayCount} day templates`);

// Fill any missing days with basic structure
for (let i = 1; i <= 30; i++) {
  if (!templates[i]) {
    templates[i] = {
      day: i,
      title: `Day ${i}: Content Template`,
      reel_prompt: `Day ${i} reel content prompt`,
      caption_template: `Day ${i} caption template`,
      signature: "With love, Sandra #BrandedBySelfie",
      hashtags: ["BrandedBySelfie", "PersonalBranding", "EmpoweredWomen"],
      seo_keywords: ["personal branding", "confidence building", "empowerment"],
      story_slides: [
        `Day ${i} story slide 1`,
        `Day ${i} story slide 2`,
        `Day ${i} story slide 3`,
        `Day ${i} story slide 4`,
        `Day ${i} story slide 5`,
        `Day ${i} story slide 6`
      ],
      cta: "Ready to transform your life? Let's do this together!"
    };
  }
}

// Save the complete templates
const sortedTemplates = Object.keys(templates)
  .sort((a, b) => parseInt(a) - parseInt(b))
  .map(key => templates[key]);

fs.writeFileSync('complete_templates.json', JSON.stringify(sortedTemplates, null, 2));

console.log('\n✅ COMPLETE 30-DAY TEMPLATES SAVED TO: complete_templates.json');
console.log(`📊 Total days: ${sortedTemplates.length}`);

// Function to parse content from Trello card descriptions
function parseContentFromDescription(desc, title) {
  const content = {
    reel_prompt: "",
    caption_template: "",
    signature: "With love, Sandra #BrandedBySelfie",
    hashtags: ["BrandedBySelfie", "PersonalBranding", "EmpoweredWomen"],
    seo_keywords: ["personal branding", "confidence building", "empowerment"],
    story_slides: [],
    cta: "Ready to transform your life? Let's do this together!"
  };
  
  // Extract reel prompt
  const reelMatch = desc.match(/\*\*Reel Prompt:\*\*\s*(.*?)(?=\n\*\*|\n\n|$)/s);
  if (reelMatch) {
    content.reel_prompt = reelMatch[1].trim().replace(/\n/g, ' ');
  }
  
  // Extract caption
  const captionMatch = desc.match(/\*\*Caption[^:]*:\*\*\s*(.*?)(?=\n\*\*|\n\n|$)/s);
  if (captionMatch) {
    content.caption_template = captionMatch[1].trim();
  }
  
  // Extract story slides (look for numbered slides)
  const slideMatches = desc.match(/(?:Slide\s*\d+[:\-]?\s*|Story\s*\d+[:\-]?\s*)(.*?)(?=\n(?:Slide\s*\d+|Story\s*\d+|\*\*)|$)/gs);
  if (slideMatches && slideMatches.length > 0) {
    content.story_slides = slideMatches.map(match => 
      match.replace(/Slide\s*\d+[:\-]?\s*|Story\s*\d+[:\-]?\s*/i, '').trim()
    ).filter(slide => slide.length > 0).slice(0, 6);
  }
  
  // If no story slides found, create default ones
  if (content.story_slides.length === 0) {
    const dayNum = title.match(/day\s*(\w+)/i)?.[1] || 'X';
    content.story_slides = [
      `Day ${dayNum}: Your transformation starts here`,
      "Every journey begins with a single step",
      "You have everything you need inside you",
      "Trust the process and trust yourself", 
      "Your future self is counting on you",
      "Ready to make it happen? Let's go!"
    ];
  }
  
  return content;
}