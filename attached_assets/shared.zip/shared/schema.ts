import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table - Updated for Supabase compatibility
export const users = pgTable("users", {
  id: text("id").primaryKey(), // UUID string for Supabase auth compatibility
  email: text("email").notNull().unique(),
  name: text("name"), // Simplified from firstName/lastName
  avatarUrl: text("avatar_url"),
  plan: text("plan").notNull().default("FREE"), // 'FREE', 'PRO', 'VIP'
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Content generations table
export const contentGenerations = pgTable("content_generations", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => users.id),
  imageUrl: text("image_url").notNull(),
  enhancedImageUrl: text("enhanced_image_url"),
  mood: text("mood").notNull(),
  filterStyle: text("filter_style").default("natural"),
  brightnessAdjust: integer("brightness_adjust").default(0),
  contrastAdjust: integer("contrast_adjust").default(0),
  captions: jsonb("captions").notNull(), // Array of 3 captions
  affirmations: jsonb("affirmations").notNull(), // Array of 3 affirmations
  poseTips: jsonb("pose_tips").notNull(), // Array of 3 pose tips
  lightingAdvice: text("lighting_advice").notNull(),
  storyCaption: text("story_caption").notNull(),
  hashtags: text("hashtags").notNull(),
  recommendedFormat: text("recommended_format").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// AI Workbooks table
export const workbooks = pgTable("workbooks", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => users.id),
  moduleId: integer("module_id").notNull(),
  moduleTitle: varchar("module_title").notNull(),
  title: text("title").notNull(),
  personalizedStrategy: text("personalized_strategy").notNull(),
  actionItems: jsonb("action_items").notNull(),
  customFrameworks: jsonb("custom_frameworks").notNull(),
  implementationPlan: text("implementation_plan").notNull(),
  keyInsights: jsonb("key_insights").notNull(),
  userProfile: jsonb("user_profile"),
  responses: jsonb("responses").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Zod schemas for Supabase compatibility
export const insertUserSchema = z.object({
  id: z.string().uuid(),
  email: z.string().email(),
  name: z.string().optional(),
  avatarUrl: z.string().optional(),
  plan: z.enum(['FREE', 'PRO', 'VIP']).default('FREE'),
});

export const insertContentGenerationSchema = createInsertSchema(contentGenerations).omit({
  id: true,
  createdAt: true,
});

export const insertWorkbookSchema = createInsertSchema(workbooks).omit({
  id: true,
  createdAt: true,
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export const signupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  firstName: z.string().min(1),
  lastName: z.string().optional(),
});

export const generateContentSchema = z.object({
  mood: z.enum(["confident", "soft", "radiant", "emotional", "boss"]),
  enhanceImage: z.boolean().default(true),
  filterStyle: z.enum([
    "natural", 
    // Light & Dreamy Collection
    "scandi-light-1", "scandi-light-2", "scandi-light-3", "scandi-light-5",
    // Dark & Moody Collection  
    "scandi-dark-1", "scandi-dark-2", "scandi-dark-4", "scandi-dark-5",
    // Deep Urban Collection
    "nordic-urban-1", "nordic-urban-2", "nordic-urban-4", "nordic-urban-5",
    // Selfie Glow Up Collection
    "glow-up-1", "glow-up-2", "glow-up-3", "glow-up-4"
  ]).default("natural"),
  brightnessAdjust: z.number().min(-50).max(50).default(0),
  contrastAdjust: z.number().min(-50).max(50).default(0),
});

// Types
// Calendar content table for weekly planner
export const calendarContent = pgTable("calendar_content", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => users.id),
  dayOfWeek: varchar("day_of_week").notNull(), // Monday, Tuesday, etc.
  caption: text("caption"),
  hook: text("hook"),
  hashtags: text("hashtags"),
  imageUrl: text("image_url"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// PDF generation logs table
export const pdfLogs = pgTable("pdf_logs", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => users.id).notNull(),
  module: varchar("module").notNull(), // module-1, module-2, etc.
  title: text("title").notNull(),
  type: varchar("type").notNull(), // workbook, guide, blueprint, report
  status: varchar("status").notNull().default("generating"), // generating, completed, failed
  templateId: text("template_id"),
  documentId: text("document_id"),
  pdfUrl: text("pdf_url"),
  inputData: jsonb("input_data"), // Store the payload data
  errorMessage: text("error_message"),
  generatedAt: timestamp("generated_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Photo library table for Uploadcare + Replicate integration
export const photoLibrary = pgTable("photo_library", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => users.id).notNull(),
  uploadcareUuid: text("uploadcare_uuid").notNull(),
  fileUrl: text("file_url").notNull(),
  fileName: text("file_name"),
  fileSize: integer("file_size"),
  tags: jsonb("tags").default([]),
  enhancedUrl: text("enhanced_url"), // New column for Replicate enhanced images
  enhancementType: varchar("enhancement_type"), // face_enhance, remove_bg, brand_visual
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCalendarContentSchema = createInsertSchema(calendarContent).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPdfLogSchema = createInsertSchema(pdfLogs).omit({
  id: true,
  generatedAt: true,
  completedAt: true,
});

export const insertPhotoLibrarySchema = createInsertSchema(photoLibrary).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Email tracking table for workbook deliveries
export const emailDeliveries = pgTable("email_deliveries", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  email: varchar("email").notNull(),
  workbookType: varchar("workbook_type").notNull(),
  pdfUrl: varchar("pdf_url").notNull(),
  zapierRequestId: varchar("zapier_request_id"),
  status: varchar("status").notNull().default("sent"), // sent, opened, clicked, downloaded
  sentAt: timestamp("sent_at").defaultNow(),
  openedAt: timestamp("opened_at"),
  clickedAt: timestamp("clicked_at"),
  downloadedAt: timestamp("downloaded_at"),
});

export const insertEmailDeliverySchema = createInsertSchema(emailDeliveries).omit({
  id: true,
  sentAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type ContentGeneration = typeof contentGenerations.$inferSelect;
export type InsertContentGeneration = z.infer<typeof insertContentGenerationSchema>;
export type Workbook = typeof workbooks.$inferSelect;
export type InsertWorkbook = z.infer<typeof insertWorkbookSchema>;
export type CalendarContent = typeof calendarContent.$inferSelect;
export type InsertCalendarContent = z.infer<typeof insertCalendarContentSchema>;
export type PdfLog = typeof pdfLogs.$inferSelect;
export type InsertPdfLog = z.infer<typeof insertPdfLogSchema>;
export type PhotoLibrary = typeof photoLibrary.$inferSelect;
export type InsertPhotoLibrary = z.infer<typeof insertPhotoLibrarySchema>;
export type EmailDelivery = typeof emailDeliveries.$inferSelect;
export type InsertEmailDelivery = z.infer<typeof insertEmailDeliverySchema>;

// Course system tables
export const coursePurchases = pgTable("course_purchases", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  productId: varchar("product_id").notNull(), // 'starter-kit' or 'branded-by-selfie'
  stripePaymentIntentId: varchar("stripe_payment_intent_id"),
  purchaseDate: timestamp("purchase_date").defaultNow(),
  amount: integer("amount").notNull(), // In cents
  status: varchar("status").default("active"), // active, refunded, expired
  createdAt: timestamp("created_at").defaultNow(),
});

export const courseProgress = pgTable("course_progress", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  productId: varchar("product_id").notNull(),
  moduleId: varchar("module_id").notNull(),
  lessonId: varchar("lesson_id"),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completed_at"),
  lastAccessed: timestamp("last_accessed").defaultNow(),
});

export const courseContent = pgTable("course_content", {
  id: serial("id").primaryKey(),
  productId: varchar("product_id").notNull(),
  moduleId: varchar("module_id").notNull(),
  lessonId: varchar("lesson_id"),
  title: varchar("title").notNull(),
  description: text("description"),
  videoUrl: varchar("video_url"),
  pdfUrl: varchar("pdf_url"),
  resourceUrls: jsonb("resource_urls"), // Array of additional resources
  orderIndex: integer("order_index").default(0),
  isPublished: boolean("is_published").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCoursePurchaseSchema = createInsertSchema(coursePurchases).omit({
  id: true,
  createdAt: true,
});

export const insertCourseProgressSchema = createInsertSchema(courseProgress).omit({
  id: true,
  lastAccessed: true,
});

export const insertCourseContentSchema = createInsertSchema(courseContent).omit({
  id: true,
  createdAt: true,
});

export type CoursePurchase = typeof coursePurchases.$inferSelect;
export type InsertCoursePurchase = z.infer<typeof insertCoursePurchaseSchema>;
export type CourseProgress = typeof courseProgress.$inferSelect;
export type InsertCourseProgress = z.infer<typeof insertCourseProgressSchema>;
export type CourseContent = typeof courseContent.$inferSelect;
export type InsertCourseContent = z.infer<typeof insertCourseContentSchema>;

export type LoginRequest = z.infer<typeof loginSchema>;
export type SignupRequest = z.infer<typeof signupSchema>;
export type GenerateContentRequest = z.infer<typeof generateContentSchema>;
